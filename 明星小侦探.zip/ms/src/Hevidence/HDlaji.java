/*
 * evidence.java
 *
 * Created on __DATE__, __TIME__
 */

package Hevidence;

import java.io.IOException;
import java.net.UnknownHostException;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

import Hotel.HBroom;
import Server.Client;

import model.goods;
import model.login2;

/**
 *
 * @author  __USER__
 */
public class HDlaji extends javax.swing.JFrame {
	private goods g;

	/** Creates new form evidence */
	public HDlaji() {
		initComponents();
		this.setLocationRelativeTo(null);
		this.setResizable(false);
		this.dispose();
		this.g = g;

	}

	//GEN-BEGIN:initComponents
	// <editor-fold defaultstate="collapsed" desc="Generated Code">
	private void initComponents() {

		jTextField1 = new javax.swing.JTextField();
		jLayeredPane1 = new javax.swing.JLayeredPane();
		jLabel2 = new javax.swing.JLabel();
		jLabel3 = new javax.swing.JLabel();
		jLabel1 = new javax.swing.JLabel();

		jTextField1.setText("jTextField1");

		setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);

		jLabel2.setFont(new java.awt.Font("Arial Unicode MS", 0, 24));
		jLabel2.setForeground(new java.awt.Color(255, 204, 0));
		jLabel2.setText("\u5783\u573e\u6876");
		jLabel2.setBounds(180, 70, 110, 50);
		jLayeredPane1.add(jLabel2, javax.swing.JLayeredPane.DEFAULT_LAYER);

		jLabel3.setFont(new java.awt.Font("Arial Unicode MS", 0, 24));
		jLabel3.setForeground(new java.awt.Color(204, 0, 0));
		jLabel3.setText("\u9a6c\u680f\u5c71\u8d35\u65cf\u96ea\u8304");
		jLabel3.setBounds(130, 130, 260, 90);
		jLayeredPane1.add(jLabel3, javax.swing.JLayeredPane.DEFAULT_LAYER);

		jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource(
				"/img/A.jpg"))); // NOI18N
		jLabel1.setBounds(0, 0, 450, 280);
		jLayeredPane1.add(jLabel1, javax.swing.JLayeredPane.DEFAULT_LAYER);

		javax.swing.GroupLayout layout = new javax.swing.GroupLayout(
				getContentPane());
		getContentPane().setLayout(layout);
		layout.setHorizontalGroup(layout.createParallelGroup(
				javax.swing.GroupLayout.Alignment.LEADING).addComponent(
				jLayeredPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 447,
				javax.swing.GroupLayout.PREFERRED_SIZE));
		layout.setVerticalGroup(layout.createParallelGroup(
				javax.swing.GroupLayout.Alignment.LEADING).addComponent(
				jLayeredPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 280,
				javax.swing.GroupLayout.PREFERRED_SIZE));

		pack();
	}// </editor-fold>
	//GEN-END:initComponents

	/**
	 * @param args the command line arguments
	 */
	public static void main(String[] args) {
		java.awt.EventQueue.invokeLater(new Runnable() {
			public void run() {
				new HDlaji().setVisible(true);
			}
		});
	}

	//GEN-BEGIN:variables
	// Variables declaration - do not modify
	private javax.swing.JLabel jLabel1;
	private javax.swing.JLabel jLabel2;
	private javax.swing.JLabel jLabel3;
	private javax.swing.JLayeredPane jLayeredPane1;
	private javax.swing.JTextField jTextField1;
	// End of variables declaration//GEN-END:variables

}