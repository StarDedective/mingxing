package model;

import java.io.Serializable;
import java.sql.ResultSet;
import java.sql.SQLException;



public class login2  implements Serializable{
	private static  String name;
	private static String pw;
	
	public login2() {
		super();
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getPw() {
		return pw;
	}
	public void setPw(String pw) {
		this.pw = pw;
	}
	public login2(String name, String pw) {
		super();
		this.name = name;
		this.pw = pw;
	}
	public static void Register(login2 a) throws SQLException, ClassNotFoundException{
		String sql = "insert into login (name,pw) values ('"+
		a.getName()+"','"+a.getPw()+"')";
		DataConnect.getStat().executeUpdate(sql);
	}
	public static login2 Login(String name,String pw) throws SQLException, ClassNotFoundException{
		login2 a = null;
		String sql = "select * from login where name='"+name+"' and pw = '"+pw+"'";
		ResultSet rs = DataConnect.getStat().executeQuery(sql);
		if(rs.next()){
			a = new login2(name,pw);
		}
		return a;
	}
}
