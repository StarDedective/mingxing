package model;

import java.sql.SQLException;

public class goods {
	private int gid;
	private String goods;//��Ʒ
	private String introduction;//��Ʒ����
	private String source;//��Ʒ������
	
	public int getGid() {
		return gid;
	}
	public void setGid(int gid) {
		this.gid = gid;
	}
	public String getGoods() {
		return goods;
	}
	public void setGoods(String goods) {
		this.goods = goods;
	}
	public String getIntroduction() {
		return introduction;
	}
	public void setIntroduction(String introduction) {
		this.introduction = introduction;
	}
	public String getSource() {
		return source;
	}
	public void setSource(String source) {
		this.source = source;
	}
	public goods(int gid, String goods, String introduction, String source) {
		super();
		this.gid = gid;
		this.goods = goods;
		this.introduction = introduction;
		this.source = source;
	}
	
	
	/*public static  void chack_good1(goods g) throws SQLException, ClassNotFoundException{//��ѯ��Ʒ��Ϣ
		String sql = "select introduction from lgoods where goods='"+g.getGoods()+"'";
		DataConnect.getStat().executeUpdate(sql);
		
	}
	*/

}
