package model;

import java.sql.ResultSet;
import java.sql.SQLException;

public class role {
	private int rid;//����id
	private String player;//��ɫ��
	private String identity;//��ɫ����
	private String killer;//��ɫ����
	private String story;//��ͷ���½���
	private String absence;//���ڳ�֤��
	private String login_id;//���id
	
	public int getRid() {
		return rid;
	}
	public void setRid(int rid) {
		this.rid = rid;
	}
	public String getPlayer() {
		return player;
	}
	public void setPlayer(String player) {
		this.player = player;
	}
	public String getIdentity() {
		return identity;
	}
	public void setIdentity(String identity) {
		this.identity = identity;
	}
	public String getKiller() {
		return killer;
	}
	public void setKiller(String killer) {
		this.killer = killer;
	}
	public String getStory() {
		return story;
	}
	public void setStory(String story) {
		this.story = story;
	}
	public String getAbsence() {
		return absence;
	}
	public void setAbsence(String absence) {
		this.absence = absence;
	}
	public String getLogin_id() {
		return login_id;
	}
	public void setLogin_id(String loginId) {
		login_id = loginId;
	}
	public role(int rid, String player, String identity, String killer,
			String story, String absence, String loginId) {
		super();
		this.rid = rid;
		this.player = player;
		this.identity = identity;
		this.killer = killer;
		this.story = story;
		this.absence = absence;
		login_id = loginId;
	}
	
	
	
	/*public void random(int rid,String login_id) throws SQLException, ClassNotFoundException{//��������ɫ
		String sql ="select name form login order by rand() limit 5 ";
		DataConnect.getStat().executeUpdate(sql);
		String sql2 ="update role set login_id=(select name from login order by rand() limit 5)";
	}
	public static void chack_role_information (role r) throws SQLException, ClassNotFoundException{//�鿴����������Ϣ	
		String sql = "select identity from role where login_id='"+r.getLogin_id()+"'";
		DataConnect.getStat().executeUpdate(sql);
		
	}
*/
}
