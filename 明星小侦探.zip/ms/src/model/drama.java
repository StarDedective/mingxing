package model;

import java.sql.SQLException;

public class drama {
	private int gid;//����id
	private String story;//�籾
	private String process;//����
	private String end;//��β
	private String evidence;//�¼�����
	
	public int getGid() {
		return gid;
	}
	public void setGid(int gid) {
		this.gid = gid;
	}
	public String getStory() {
		return story;
	}
	public void setStory(String story) {
		this.story = story;
	}
	public String getProcess() {
		return process;
	}
	public void setProcess(String process) {
		this.process = process;
	}
	public String getEnd() {
		return end;
	}
	public void setEnd(String end) {
		this.end = end;
	}
	public String getEvidence() {
		return evidence;
	}
	public void setEvidence(String evidence) {
		this.evidence = evidence;
	}
	public drama(int gid, String story, String process, String end,
			String evidence) {
		super();
		this.gid = gid;
		this.story = story;
		this.process = process;
		this.end = end;
		this.evidence = evidence;
	}
	/*public static  void choose(drama d) throws SQLException, ClassNotFoundException {//ѡ��籾
		String sql = "select evidence from drama where gid='"+d.getGid()+"'";
		DataConnect.getStat().executeUpdate(sql);	
	}
	public void getNumber(){//��ȡѡ��˾籾����������5�˿�ʼ
		
	}
*/
}
