package model;

import java.sql.SQLException;

public class vote {
	private int vid;//����id
	private String first;//һ��ͶƱ��ɫ
	private String second;//����ͶƱ��ɫ
	private String killer;//����
	
	public int getVid() {
		return vid;
	}
	public void setVid(int vid) {
		this.vid = vid;
	}
	public String getFirst() {
		return first;
	}
	public void setFirst(String first) {
		this.first = first;
	}
	public String getSecond() {
		return second;
	}
	public void setSecond(String second) {
		this.second = second;
	}
	public String getKiller() {
		return killer;
	}
	public void setKiller(String killer) {
		this.killer = killer;
	}
	public vote(int vid, String first, String second, String killer) {
		super();
		this.vid = vid;
		this.first = first;
		this.second = second;
		this.killer = killer;
	}
	public static void vote1(vote u) throws SQLException, ClassNotFoundException{//һ��ͶƱ
		String sql = "update vote set first='"+u.getFirst()+"' where vid ="+u.getVid();
		DataConnect.getStat().executeUpdate(sql);
	}
	public static void vote2(vote u) throws SQLException, ClassNotFoundException{//һ��ͶƱ
		String sql = "update vote set second='"+u.getSecond()+"' where vid ="+u.getVid();
		DataConnect.getStat().executeUpdate(sql);
	}
	public static void comparison1(vote u) throws SQLException, ClassNotFoundException{//�������������������Ա�
		String a = "select second from vote where vid='"+u.getVid()+"'";
		String b = "select killer from vote where vid='"+u.getVid()+"'";
		DataConnect.getStat().executeUpdate(a);
		DataConnect.getStat().executeUpdate(b);
		if(a.equals(b)){
			//������Ϸ�ɹ�����
		}
		else{
			//��Ϸʧ�ܽ���
		}
	}
}
