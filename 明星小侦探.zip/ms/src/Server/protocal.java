package Server;

public interface protocal {

	int Login=1001;
	int Register=1002;
	int vote1=1003;
	int vote2=1004;
	int comparison1=1005;
}
