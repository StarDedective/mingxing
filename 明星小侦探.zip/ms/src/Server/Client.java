package Server;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;
import java.net.UnknownHostException;
import java.sql.SQLException;
import java.util.ArrayList;

import model.drama;
import model.goods;
import model.login2;
import model.role;
import model.vote;

public class Client  implements protocal{
	private static Socket s;
	private static ObjectOutputStream oos;
	private static ObjectInputStream ois;
	private static void init() throws UnknownHostException, IOException {
		s = new Socket("106.54.107.190",12333);
		oos = new ObjectOutputStream(s.getOutputStream());
		ois = new ObjectInputStream(s.getInputStream());
	}
	public static void vote1(int vid,String first) throws UnknownHostException, IOException{
		init();
		oos.writeInt(vote1);
		oos.flush();
		oos.writeInt(vid);
		oos.flush();
		oos.writeUTF(first);
		oos.flush();
	}
	public static void vote2(int vid,String second) throws UnknownHostException, IOException{
		init();
		oos.writeInt(vote2);
		oos.flush();
		oos.writeInt(vid);
		oos.flush();
		oos.writeUTF(second);
		oos.flush();
	}
	public static void comparison1(int vid) throws IOException{
		init();
		oos.writeInt(comparison1);
		oos.flush();
		oos.writeInt(vid);
		oos.flush();
	}
	public static login2 Login(String name,String pw) throws  IOException,
	ClassNotFoundException {
		init();
		oos.writeInt(Login);
		oos.flush();
		oos.writeUTF(name);
		oos.flush();
		oos.writeUTF(pw);
		oos.flush();
		login2 a=(login2) ois.readObject();
		return a;
		
	}
	public static void Register(String name,String pw) throws ClassNotFoundException, UnknownHostException, IOException{
		init();
		oos.writeInt(Register);
		oos.flush();
		oos.writeObject(name);
		oos.flush();
		oos.writeUTF(pw);
		oos.flush();
	}
}