package Server;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.ServerSocket;
import java.net.Socket;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;


import model.DataConnect;
import model.drama;
import model.goods;
import model.login2;
import model.role;
import model.vote;



public class server implements protocal{
	private static ServerSocket ss;
	private static Socket s;
	private static ObjectInputStream ois;
	private static ObjectOutputStream oos;
	 
	public server() throws IOException, SQLException, ClassNotFoundException{
		ServerSocket ss = new ServerSocket(12333);
		while (true) {
			s = ss.accept();
			ois = new ObjectInputStream(s.getInputStream());
			oos = new ObjectOutputStream(s.getOutputStream());
			int command = ois.readInt();
			if (command == Login) {
				this.Login();
			}
			if (command == Register) {
				this.Register();
			}
			if(command == vote1){
				this.vote1();
			}
			if(command == vote2){
				this.vote2();
			}
			if(command == comparison1){
				this.comparison1();
			}
			}
		
	}
	private void Login() throws  IOException,
	ClassNotFoundException, SQLException{
		String name=ois.readUTF();
		String pw=ois.readUTF();
		/*login2 a=null;
		String sql = "select * from login where name='"+name+"' and pw = '"+pw+"'";
		ResultSet rs = DataConnect.getStat().executeQuery(sql);
		if(rs.next()){
			a = new login2(name,pw);
		}
		oos.writeObject(a);
		oos.flush();*/
	}
	private  void Register() throws IOException,
	ClassNotFoundException, SQLException{
		String name=(String) ois.readObject();
		String pw=(String) ois.readObject();
	
		
	}
	public void vote1() throws IOException, SQLException, ClassNotFoundException{//һ��ͶƱ
		
		vote u=null;
		String sql = "select count from hotel where role";
		DataConnect.getStat().executeUpdate(sql);
		oos.writeObject(u);
		oos.flush();
	}
	public void vote2() throws IOException, SQLException, ClassNotFoundException{//����ͶƱ
		int vid=ois.readInt();
		String second=ois.readUTF();
		vote u=null;
		String sql = "update vote set second='"+second+"' where vid ="+vid;
		DataConnect.getStat().executeUpdate(sql);
		oos.writeObject(u);
		oos.flush();
	}
	public static void comparison1() throws IOException, SQLException, ClassNotFoundException{//�ڶ���ͶƱ�����ֶԱ�
		int vid=ois.readInt();
		vote u=null;
		String a = "select second from vote where vid='"+vid;
		String b = "select killer from vote where vid='"+vid;
		DataConnect.getStat().executeUpdate(a);
		DataConnect.getStat().executeUpdate(b);
		if(a.equals(b)){
			//������Ϸ�ɹ�����
		}
		else{
			//��Ϸʧ�ܽ���
		}
		oos.writeObject(u);
		oos.flush();
	}
	
	public static void main(String[] args) throws SQLException, ClassNotFoundException {
		try {
			new server();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
