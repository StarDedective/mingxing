/*
 * JJR.java
 *
 * Created on __DATE__, __TIME__
 */

package Jlove;

import zhu.analyse;
import zhu.analyse2;
import zhu.daojishi2;
import zhu.roles;
import zhu.roles2;

/**
 *
 * @author  __USER__
 */
public class JJR extends javax.swing.JFrame {

	/** Creates new form JJR */
	public JJR() {
		initComponents();
		this.setLocationRelativeTo(null);
		this.setResizable(false);
	}

	//GEN-BEGIN:initComponents
	// <editor-fold defaultstate="collapsed" desc="Generated Code">
	private void initComponents() {

		jLayeredPane1 = new javax.swing.JLayeredPane();
		jButton1 = new javax.swing.JButton();
		jButton2 = new javax.swing.JButton();
		jButton3 = new javax.swing.JButton();
		jButton4 = new javax.swing.JButton();
		jButton5 = new javax.swing.JButton();
		jButton6 = new javax.swing.JButton();
		jButton7 = new javax.swing.JButton();
		jLabel1 = new javax.swing.JLabel();
		jButton8 = new javax.swing.JButton();

		setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);

		jButton1.setBackground(new java.awt.Color(102, 102, 102));
		jButton1.setFont(new java.awt.Font("Arial Unicode MS", 0, 24));
		jButton1.setText("OK'room");
		jButton1.addActionListener(new java.awt.event.ActionListener() {
			public void actionPerformed(java.awt.event.ActionEvent evt) {
				jButton1ActionPerformed(evt);
			}
		});
		jButton1.setBounds(50, 250, 190, 170);
		jLayeredPane1.add(jButton1, javax.swing.JLayeredPane.DEFAULT_LAYER);

		jButton2.setBackground(new java.awt.Color(102, 102, 102));
		jButton2.setFont(new java.awt.Font("Arial Unicode MS", 0, 24));
		jButton2.setText("\u6492IT'room");
		jButton2.addActionListener(new java.awt.event.ActionListener() {
			public void actionPerformed(java.awt.event.ActionEvent evt) {
				jButton2ActionPerformed(evt);
			}
		});
		jButton2.setBounds(450, 260, 180, 160);
		jLayeredPane1.add(jButton2, javax.swing.JLayeredPane.DEFAULT_LAYER);

		jButton3.setBackground(new java.awt.Color(102, 102, 102));
		jButton3.setFont(new java.awt.Font("Arial Unicode MS", 0, 24));
		jButton3.setText("\u5395\u6240");
		jButton3.addActionListener(new java.awt.event.ActionListener() {
			public void actionPerformed(java.awt.event.ActionEvent evt) {
				jButton3ActionPerformed(evt);
			}
		});
		jButton3.setBounds(870, 260, 180, 170);
		jLayeredPane1.add(jButton3, javax.swing.JLayeredPane.DEFAULT_LAYER);

		jButton4.setBackground(new java.awt.Color(102, 102, 102));
		jButton4.setFont(new java.awt.Font("Arial Unicode MS", 0, 24));
		jButton4.setText("\u8c2d\u604b\u7231'room");
		jButton4.addActionListener(new java.awt.event.ActionListener() {
			public void actionPerformed(java.awt.event.ActionEvent evt) {
				jButton4ActionPerformed(evt);
			}
		});
		jButton4.setBounds(1260, 260, 180, 170);
		jLayeredPane1.add(jButton4, javax.swing.JLayeredPane.DEFAULT_LAYER);

		jButton5.setBackground(new java.awt.Color(102, 102, 102));
		jButton5.setFont(new java.awt.Font("Arial Unicode MS", 0, 24));
		jButton5.setText("\u6e38\u6cf3\u6c60");
		jButton5.addActionListener(new java.awt.event.ActionListener() {
			public void actionPerformed(java.awt.event.ActionEvent evt) {
				jButton5ActionPerformed(evt);
			}
		});
		jButton5.setBounds(1060, 540, 170, 170);
		jLayeredPane1.add(jButton5, javax.swing.JLayeredPane.DEFAULT_LAYER);

		jButton6.setBackground(new java.awt.Color(102, 102, 102));
		jButton6.setFont(new java.awt.Font("Arial Unicode MS", 0, 24));
		jButton6.setText("\u767d\u5f00\u6c34'room");
		jButton6.addActionListener(new java.awt.event.ActionListener() {
			public void actionPerformed(java.awt.event.ActionEvent evt) {
				jButton6ActionPerformed(evt);
			}
		});
		jButton6.setBounds(660, 540, 180, 160);
		jLayeredPane1.add(jButton6, javax.swing.JLayeredPane.DEFAULT_LAYER);

		jButton7.setBackground(new java.awt.Color(102, 102, 102));
		jButton7.setFont(new java.awt.Font("Arial Unicode MS", 0, 24));
		jButton7.setText("\u9b4f\u5a5a\u592b'room");
		jButton7.addActionListener(new java.awt.event.ActionListener() {
			public void actionPerformed(java.awt.event.ActionEvent evt) {
				jButton7ActionPerformed(evt);
			}
		});
		jButton7.setBounds(250, 540, 180, 160);
		jLayeredPane1.add(jButton7, javax.swing.JLayeredPane.DEFAULT_LAYER);

		jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource(
				"/img/7.jpg"))); // NOI18N
		jLabel1.setBounds(0, 0, 1480, 830);
		jLayeredPane1.add(jLabel1, javax.swing.JLayeredPane.DEFAULT_LAYER);

		jButton8.setContentAreaFilled(false);
		jButton8.addActionListener(new java.awt.event.ActionListener() {
			public void actionPerformed(java.awt.event.ActionEvent evt) {
				jButton8ActionPerformed(evt);
			}
		});
		jButton8.setBounds(1250, 30, 200, 120);
		jLayeredPane1.add(jButton8, javax.swing.JLayeredPane.DEFAULT_LAYER);

		javax.swing.GroupLayout layout = new javax.swing.GroupLayout(
				getContentPane());
		getContentPane().setLayout(layout);
		layout.setHorizontalGroup(layout.createParallelGroup(
				javax.swing.GroupLayout.Alignment.LEADING).addComponent(
				jLayeredPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 1477,
				javax.swing.GroupLayout.PREFERRED_SIZE));
		layout.setVerticalGroup(layout.createParallelGroup(
				javax.swing.GroupLayout.Alignment.LEADING).addComponent(
				jLayeredPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 829,
				javax.swing.GroupLayout.PREFERRED_SIZE));

		pack();
	}// </editor-fold>
	//GEN-END:initComponents

	private void jButton8ActionPerformed(java.awt.event.ActionEvent evt) {
		new roles2().setVisible(true);
	}

	private void jButton7ActionPerformed(java.awt.event.ActionEvent evt) {
		this.dispose();
		new JWroom().setVisible(true);
	}

	private void jButton6ActionPerformed(java.awt.event.ActionEvent evt) {
		this.dispose();
		// TODO add your handling code here:
		new JBroom().setVisible(true);
	}

	private void jButton5ActionPerformed(java.awt.event.ActionEvent evt) {
		this.dispose();
		new Jswim().setVisible(true);
	}

	private void jButton4ActionPerformed(java.awt.event.ActionEvent evt) {
		this.dispose();
		new JTroom().setVisible(true);
	}

	private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {
		this.dispose();
		new Jwc().setVisible(true);
	}

	private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {
		this.dispose();
		new JSroom().setVisible(true);
	}

	private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {
		this.dispose();
		new JOroom().setVisible(true);
	}

	/**
	 * @param args the command line arguments
	 */
	public static void main(String args[]) {
		java.awt.EventQueue.invokeLater(new Runnable() {
			public void run() {
				new JJR().setVisible(true);
				 int time=300;
				 while(time>0) {
	                    time--;
	                    if(time==0) {//��ʱ��ֻʣ5��ʱ����
	                        //jLabel.setForeground(Color.RED);
	                    	new JJR().setVisible(false);
	                    	new Jvote().setVisible(true);
	                    }
	                    try {
	                        Thread.sleep(1000);
	                    } catch (InterruptedException e) {
	                        e.printStackTrace();
	                    }
	                }
			}
		});
	}

	//GEN-BEGIN:variables
	// Variables declaration - do not modify
	private javax.swing.JButton jButton1;
	private javax.swing.JButton jButton2;
	private javax.swing.JButton jButton3;
	private javax.swing.JButton jButton4;
	private javax.swing.JButton jButton5;
	private javax.swing.JButton jButton6;
	private javax.swing.JButton jButton7;
	private javax.swing.JButton jButton8;
	private javax.swing.JLabel jLabel1;
	private javax.swing.JLayeredPane jLayeredPane1;
	// End of variables declaration//GEN-END:variables

}