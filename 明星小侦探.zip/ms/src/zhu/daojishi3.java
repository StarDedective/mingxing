package zhu;

import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;

import Hotel.Hvote;
import Tcase.Tvote;

public class daojishi3 extends JFrame {
    JButton jButton;
    JLabel jLabel;
    int time=300;
    public daojishi3() {
        FlowLayout fl=new FlowLayout(FlowLayout.CENTER);
        this.setLayout(fl);
        //Ϊ��ťjButton���Ӽ�������ʵ�ֵ��ʱ����ʱ���¿�ʼ
        jButton=new JButton("���¿�ʼ");
        jButton.addActionListener(new ActionListener() {
            //@Override
            public void actionPerformed(ActionEvent arg0) {
                dispose();//�رյ�ǰ����
                //new daojishi();//�½�һ������
            }

        }
    );
        //��������һ���߳��ڲ�����ʵ��ʱ�䵹��ʱ��������ƪ����ĺ���
        jLabel=new JLabel();
        new Thread(){
            public void run() {
                while(time>0) {
                    time--;
                    if(time==0) {//��ʱ��ֻʣ5��ʱ����
                        //jLabel.setForeground(Color.RED);
                    	new daojishi3().setVisible(false);
                    	new Tvote().setVisible(true);
                    }
                    jLabel.setText(time+"��");
                    try {
                        Thread.sleep(1000);
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                }
            }

        }.start();

        //this.add(jButton);
        this.add(jLabel);
        this.setTitle("����ʱ");
        this.setSize(300, 200);
        this.setResizable(true);
        this.setVisible(true);
        this.setDefaultCloseOperation(EXIT_ON_CLOSE);
    }

    public static void main(String[] args) {
        new daojishi();

    }

}
